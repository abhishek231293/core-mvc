﻿<?php
    session_start();

    unset($_SESSION['validUser']);

    header('location: index.php');



?>
t>