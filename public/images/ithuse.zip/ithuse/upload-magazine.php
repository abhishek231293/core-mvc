﻿<?php
session_start();
if(!isset($_SESSION['validUser'])){
    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="shortcut icon" type="image/png" href="img/favicon.png"/>
    <title>Doha | Upload Magazine</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Morris -->
    <link href="css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- Sweet Alert -->
    <link href="css/sweetalert.css" rel="stylesheet">

    <link href="css/plugins/datapicker/datepicker3.css" rel="stylesheet">

    <!--Upload File-->
    <link href="css/animate.css" rel="stylesheet">
    <!--<link href="css/plugins/dropzone/basic.css" rel="stylesheet">-->
    <link href="css/plugins/dropzone/dropzone.css" rel="stylesheet">
</head>

<style>
    .dropzone-previews a{
        cursor : pointer !important;
        color: white !important;
        background-color: #1ab394;
        font-family: 'Open Sans';
        font-size: 10px;
        font-weight: 600;
        padding: 3px 8px;
        text-shadow: none;
    }
</style>
<body>
<div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                            <span>
                                <img alt="image" class="img-circle" src="img/profile_small.jpg" />
                            </span>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear">
                                    <span class="block m-t-xs">
                                        <strong class="font-bold"></strong>
                                    </span> <span class="text-muted text-xs block">Admin <b class="caret"></b></span>
                                </span>
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a href="changepassword.html">Change Password</a></li>
                            <li class="divider"></li>
                            <li><a href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        DOHA
                    </div>
                </li>
                <li>
                    <a href="all-magazine.php"><i class="fa fa-book"></i> <span class="nav-label">All Magazine </span>

                        <span id= "totalCount" class="label label-warning pull-right">
                                <?php echo $_SESSION["totalRecords"]; ?>
                         </span>

                    </a>
                </li>
                <li class="active">
                    <a href="upload-magazine.php"><i class="fa fa-cloud-upload"></i> <span class="nav-label">Upload Magazine </span></a>
                </li>
            </ul>
        </div>
    </nav>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                <div class="navbar-header">
                    <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                </div>
                <ul class="nav navbar-top-links navbar-right">
                    <li>
                        <span class="m-r-sm text-muted welcome-message">Welcome Admin</span>
                    </li>
                    <li>
                        <a href="logout.php">
                            <i class="fa fa-sign-out"></i> Log out
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="wrapper wrapper-content animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Dropzone Area </h5>
                        </div>
                        <div class="ibox-content">
                            <label class="font-noraml">Upload Date</label>
                            <div class="row">
                                <div class="col-md-3 form-group" id="data_1">
                                    <div class="input-group date">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input type="text" class="form-control" id="uplodedDate">
                                    </div>
                                </div>
                                <div class="col-md-3 form-group">
                                    <input name="fName" id="fName" class="form-control" placeholder="File Name" required="">
                                </div>
                            </div>
                            <form id="my-awesome-dropzone" action="/ithuse/controller/code.php" class="dropzone" method="post">
                                <div class="dropzone-previews" id = "dropzone-previews"></div>
                                <!--<button type="submit" class="btn btn-primary pull-right">Upload File</button>-->
                            </form>
                            <div class="row spinloader text-center" style="height: 100px;padding-top: 2%;display: none">
                                <i class="fa fa-spinner fa-4x fa-spin"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <div>
                <strong>Copyright</strong> Example Company &copy; 2014-2015
            </div>
        </div>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-2.1.1.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>


<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>

<!-- jQuery UI -->
<script src="js/plugins/jquery-ui/jquery-ui.min.js"></script>

<!-- Data picker -->
<script src="js/plugins/datapicker/bootstrap-datepicker.js"></script>

<!-- Sweet alert -->
<script src="js/sweetalert.min.js"></script>

<!-- DROPZONE -->
<script src="js/plugins/dropzone/dropzone.js"></script>

<script>
    $('#data_1 .input-group.date').datepicker({

        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        maxDate: new Date()
    });
    $(document).ready(function(){

        var date = new Date();
        var day = date.getDate();
        var monthIndex = date.getMonth() + 1;
        var year = date.getFullYear();

        $currentDate = monthIndex + '/' + day + '/' + year;

        $("#uplodedDate").val($currentDate);

        Dropzone.options.myAwesomeDropzone = {
            paramName: "file",
            maxFilesize: 3463994,
            url: '/ithuse/controller/code.php',
            previewsContainer: "#dropzone-previews",
            uploadMultiple: true,
            parallelUploads: 1,
            maxFiles: 1,
            init: function () {
                var cd;
                this.on("success", function (file, response) {
                    $('.dz-progress').hide();
                    $('.dz-size').hide();
                    $('.dz-error-mark').hide();

                    cd = response;
                });
                this.on("addedfile", function (file) {

                    $fileName = (file.name);
                    var res = $fileName.split(".pdf");

                    $("#fName").val(res[0]);

                    var addButton = Dropzone.createElement("<a href=\"#\" id=\"myFile\">Add file</a>");
                    var _this = this;

                    $(".dropzone-previews").find('a').css('cursor', 'pointer');

                    addButton.addEventListener("click", function (e) {

                        file.name = $("#fName").val();

                        $(".spinloader").show();
                        $(".dropzone").hide();

                        e.preventDefault();
                        e.stopPropagation();
                        _this.removeFile(file);


                        var data = new FormData();
                        /*
                         $.each($(file), function(i, file) {
                         data.append('file-'+i, file);
                         });*/

                        $.each($(file), function(i, file) {
                            data.append('file', file);
                            data.append('fname', $("#fName").val());
                            data.append('uplodedDate', $("#uplodedDate").val());
                        });

                        $.ajax({
                            type: 'POST',
                            url: '/ithuse/controller/code.php',
                            data: data,
                            cache: false,
                            contentType: false,
                            processData: false,
                            success: function(data) {
                                $(".spinloader").hide();
                                $(".dropzone").show();

                                if(parseInt(data) == -1){
                                    //alert("Please select valid file format !!");
                                    sweetAlert("Error..!", "Please select valid file format !!", "error");
                                }else{
                                    //alert("File uploaded SuccessFully !!");
                                    sweetAlert("Success..!", "File uploaded SuccessFully !!", "success");

                                    var totalCount = parseInt($("#totalCount").html()) + 1;

                                    $("#totalCount").html(totalCount);



                                }

                            /*
                            if(parseInt(data) == 1){
                                alert("File uploaded SuccessFully !!");
                            }else{
                                alert("Error accured please try again !!");
                                return;
                            }
                            */
                        }
                        });
                    });
                    file.previewElement.appendChild(addButton);

                    /*
                     var removeButton = Dropzone.createElement("<a href=\"#\">Remove file</a>");
                     var _this = this;
                     removeButton.addEventListener("click", function (e) {
                     e.preventDefault();
                     e.stopPropagation();
                     _this.removeFile(file);

                     });
                     file.previewElement.appendChild(removeButton);
                     */
                });
            }
        };
    });

    //        $("form#my-awesome-dropzone").dropzone({ url: "/ithuse/controller/code.php" });

</script>
</body>
</html>
