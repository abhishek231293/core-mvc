<?php include_once ("dbconnect.php"); ?>
<?php
	// Class for inserting data into database
	class InsertData 
	{
	  public function insert($name,$email,$age,$country){
				  
				    // Creating object for the database connection	
					$obj=new dbconnect();
					$obj->connectdb();
					
					// Query for inserting data into table	
					@$sql = "INSERT INTO tbl_std(sname,age,email,country)"."VALUES ('$name', '$age', '$email', '$country')";

					// Executing the Query for the Desired Table
					$retval = mysql_query( $sql);
					if(! $retval ) {
					die('Could not enter data: ' . mysql_error());
					}
					// Closing the Database
					mysql_close($conn);
					header( 'Location: ../view/Insert.php?q=1' );
			}
	}
?>