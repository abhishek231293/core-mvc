<?php
	// Class for creating the connection
	class dbconnect
	{
	  public $conn;
	  public function connectdb(){
		  //$this->conn = mysql_connect('69.60.115.13', 'root', 'newpassword123');
		  	$this->conn = mysql_connect('localhost', 'root', '');

			 if(! $this->conn ) {
				  die('Could not connect: ' . mysql_error());
			 }
			 // Fetching Desired Database
			 mysql_select_db("magzine_demo_db", $this->conn) or die("Error on database connection");
		}	 
     }
?>