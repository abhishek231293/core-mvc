<?php include_once ("dbconnect.php"); ?>
<?php
	// Class for inserting data into database
	class DbOperation
	{
	  public function runQuery($query=null){
				  
				    // Creating object for the database connection	
					$obj=new dbconnect();
					$obj->connectdb();

                    if($query){//echo $query;exit;
                        $retval = mysql_query( $query);
                        if(! $retval ) {
                            die('Could not enter data: ' . mysql_error());
                        }else{
                            return mysql_insert_id();
                        }
                        // Closing the Database
                        mysql_close($conn);
                    }

			}


        public function selectQuery($query, $toEncode = null)
        {//echo "here";exit;
            $obj=new dbconnect();
            $obj->connectdb();


            try {
                $numResults = 0;

                $result = mysql_query($query) ;

                if ($result) {
                    $numResults = mysql_num_rows($result);
                }


                $dataToReturn = array();
                $indexNumber = 0;
                if ($numResults) {
                    while ($rowset = mysql_fetch_array($result)) {
                        $resultSet = array();
                        foreach ($rowset as $rowIndex => $row) {
                            if (!is_int($rowIndex))
                                $resultSet[$rowIndex] = $row;
                        }
                        if (count($resultSet))
                            $dataToReturn[$indexNumber] = $resultSet;
                        $indexNumber++;
                    }
                }
                return $dataToReturn;
            }
            catch (exception $e) {
                echo "Error occured : " . $e->getMessage();
                exit;
            }
        }
	}
?>