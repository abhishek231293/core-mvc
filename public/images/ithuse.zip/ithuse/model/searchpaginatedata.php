<?php
include_once('dbconnect.php');
		$obj= new dbconnect();
		$obj->connectdb();

class paginator{
		
		//	Function for Retriving all Record set. 
        function getallrecord(){
			$result = mysql_query("SELECT * FROM tbl_std");
			return $result;
		}
		
		// Function for Retriving Search Record set
        function getsearchrecord($field, $value){
			$query="SELECT * FROM tbl_std WHERE $field = '$value'";
			//$query="SELECT * FROM tbl_std WHERE ".$field."= '$value'";
			//echo $query;			
			$result = mysql_query($query);
			return $result;
		}	
		
		// Function for Retriving Search Record set
        function createQuery($field = null, $value = null,$limit = 3,$startPage = 0){
			if($field){
				$query="SELECT * FROM tbl_std WHERE $field = '$value'";
			}else{
				$query="SELECT * FROM tbl_std";
			}
			
			if($startPage){
				$startPage = ($startPage-1)*$limit;
			}
			if($limit){
				$query  .=  " limit ".$startPage.",".$limit;
			}
			
			
			return $query;
		}		
		
		// Function for Retriving total number of record.
		function getrows($totl_record){
			@$total_rows = mysql_num_rows($totl_record);
			return $total_rows;
				
		}
		
		// Function for Getting the Range of record you want to display.
		function getrange(){
			if(isset($_GET['pagination'])){
				$per_page=$_GET['pagination'];
			}
			else{		
				$per_page = 3;
			}
			return $per_page;
		}
		
		// Function for Retriving first and last page of Pagination
		function getfirstlast($total_pages, $per_page){
			if (isset($_GET['page'])) {
					$show_page = $_GET['page'];    //For finding the status of the current page
					
					if ($show_page > 0 && $show_page <= $total_pages) {
						$start = ($show_page - 1) * $per_page;
						$end = $start + $per_page;
					} 
					else {
						//show first set of results
						$start = 0;              
						$end = $per_page;
					}
			} 
			else {
				// if no value in QueryString
				$start = 0;
				$end = $per_page;
				
			}
			//return $start;
			return array($start, $end);		
		}	
	
		// Function for Retriving the total number of pages Generated.
		function getpages($total_results, $per_page){
		
			$total_pages = ceil($total_results / $per_page);
			return $total_pages;
				
		}	
		
		function getResultData($query){
				$result = mysql_query($query);
				$numResults = null;
				if ($result) {
					$numResults = mysql_num_rows($result);
				}
				
				$dataToReturn = array();
				$indexNumber = 0;
				if ($numResults) {
					while ($rowset = mysql_fetch_array($result)) {
						$resultSet = array();
						foreach ($rowset as $rowIndex => $row) {
							if (!is_int($rowIndex))
								$resultSet[$rowIndex] = $row;
						}
							if (count($resultSet))
								$dataToReturn[$indexNumber] = $resultSet;
							$indexNumber++;
					}
				}
				return $dataToReturn;
		}
		
		
		
		// Function for Getting Pagination. page variable is used for the current page and tpages is used for total pagination range that is to be generate.
		function getpaginate($page, $tpages) {
			$firstlabel = "&lsaquo;&lsaquo; First";
			$prevlabel = "&lsaquo; Prev";
			$nextlabel = "Next &rsaquo;";
			$lastlabel = "Last &rsaquo;&rsaquo;";
			$out = "";
			
			//For First Page Link
			$out.= "<li><a  href=\"Javascript:createPagination(1)\">" . $firstlabel . "</a>\n</li>";
			
			// For previous link
		    if($page==1){
		  
		  		$out.= "<span style='font-size:11px'>" . $prevlabel . "</span>\n</li>";
			}
			else{
				$out.= "<li><a  href=\"Javascript:createPagination(".($page-1).")\">" . $prevlabel . "</a>\n</li>";
			}	
			//For Inner links and 2 is added or substracted because we wants only 3 inner links		
			if($page < ($tpages-2)){
				if($page == 0)
					$pmin = 1;
				else
					$pmin=$page;	//for min page
			}
			else{
				$pmin=$tpages-2;
			}
			
			if($pmin < ($tpages-2)){
				$pmax=$pmin+2;
			}
			else{
				$pmax=$tpages;
			}
			
			if($pmin == 0){
				 $pmin = 1;
			}
				 
			for ($i = $pmin; $i <= $pmax; $i++) {
					
				if ($i == $page) {
					$out.= "<li  class=\"active\"><a  href=\"Javascript:createPagination(".$i.")\">" . $i . "</a></li>\n";
				} elseif ($i == 1) {
					$out.= "<li><a  href=\"Javascript:createPagination(1)\">" . $i . "</a>\n</li>";
				} else {
					$out.= "<li><a   href=\"Javascript:createPagination(".$i.")\">" . $i . "</a>\n</li>";
				}
				
			}
			
			// For next link
			if ($page < $tpages) {
				$out.= "<li><a   href=\"Javascript:createPagination(".($page+1).")\">" . $nextlabel . "</a>\n</li>";
			} else {
				$out.= "<li><span style='font-size:11px'>" . $nextlabel . "</span>\n</li>";
			}
			
			//For Last Page Link
			$out.= "<li><a   href=\"Javascript:createPagination($tpages)\" >" . $lastlabel . "</a>\n</li>";			
			$out.= "";
			return $out;
		}
}
?>