<?php include_once ("dbconnect.php"); ?>
<?php
	// Class for updating data into database
	class UpdateData 
	{
	   public function update($data,$condition = null){
				  
				    // Creating object for the database connection	
					$obj=new dbconnect();
					$obj->connectdb();
					
					// Query for updating data into table	
					//@$sql = "UPDATE tbl_std SET sname='$name', age='$age', email='$email', country='$country' WHERE sid='$id'";
					@$sql = "UPDATE tbl_std SET ";
					
					$commaFlag = false;
					foreach($data as $field=>$value){
						if($commaFlag){
							@$sql .=  ",";
						}
						@$sql .=  $field." = '".$value."'";
						$commaFlag = true;
					}
					
					if($condition)
						@$sql .= " WHERE ".$condition;

					// Executing the Query for the Desired Table
					$retval = mysql_query( $sql);
					if(! $retval ) {
						die('Could not enter data: ' . mysql_error());
					}
					// Closing the Database
					mysql_close($obj->conn);
					//header( 'Location: ../view/edit.php?q=1' );
		}
	}
?>