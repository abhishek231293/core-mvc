<?php
include_once('dbconnect.php');
$obj= new dbconnect();
$obj->connectdb();

class paginator{

	// Function for Retriving the Record set.
	function getrecord(){
		$result = mysql_query("SELECT * FROM `magzine_detail` WHERE is_active = '1' order by `magzine_detail`.`updated_at` DESC ");
		return $result;
	}

	// Function for Retriving total number of record.
	function getrows($totl_record){
		$total_rows = mysql_num_rows($totl_record);
		return $total_rows;

	}

	// Function for Getting the Range of record you want to display.
	function getrange(){
		if(isset($_GET['pagination'])){
			$per_page=$_GET['pagination'];
		}
		else{
			$per_page = 10;
		}
		return $per_page;
	}

	// Function for Retriving first and last page of Pagination
	function getfirstlast($total_pages, $per_page){
		if (isset($_GET['page'])) {
			$show_page = $_GET['page'];    //For finding the status of the current page

			if ($show_page > 0 && $show_page <= $total_pages) {
				$start = ($show_page - 1) * $per_page;
				$end = $start + $per_page;
			}
			else {
				//show first set of results
				$start = 0;
				$end = $per_page;
			}
		}
		else {
			// if no value in QueryString
			$start = 0;
			$end = $per_page;

		}
		//return $start;
		return array($start, $end);
	}

	// Function for Retriving the total number of pages Generated.
	function getpages($total_results, $per_page){
		$total_pages = ceil($total_results / $per_page);
		return $total_pages;

	}
	// Function for Getting Pagination.
	function getpaginate($reload, $page, $tpages) {
		$firstlabel = "&lsaquo;&lsaquo; First";
		$prevlabel = "&lsaquo; Prev";
		$nextlabel = "Next &rsaquo;";
		$lastlabel = "Last &rsaquo;&rsaquo;";
		$out = "";


		// or First Page Link and previous link
		if($page != 1){

			$out.= "<li><a  href=\"" . $reload . "&amp;page=" . 1 . "\">" . $firstlabel . "</a>\n</li>";
			//$out.= "<li><a  href=\"" . $reload . "\">" . $prevlabel . "</a>\n</li>";
			$out.= "<li><a  href=\"" . $reload . "&amp;page=" . ($page - 1) . "\">" . $prevlabel . "</a>\n</li>";
		}
		else{
			//$out.= "<li><a  href=\"" . $reload . "&amp;page=" . ($page - 1) . "\">" . $prevlabel . "</a>\n</li>";
		}
		//For Inner links and 2 is added or substracted because we wants only 3 inner links
		if($page < ($tpages-2)){
			$pmin=$page;   //for min page
		}
		else{
			$pmin=$tpages-2;
		}

		if($pmin < ($tpages-2)){
			$pmax=$pmin+2;
		}
		else{
			$pmax=$tpages;
		}

		//echo $pmin ."----".$pmax;

		if($pmin == 0){
			$pmin = 1;
		}
		for ($i = $pmin; $i <= $pmax; $i++) {

			if ($i == $page) {
				$out.= "<li  class=\"active\"><a href=''>" . $i . "</a></li>\n";
			} elseif ($i == 1) {
				$out.= "<li><a  href=\"" . $reload . "\">" . $i . "</a>\n</li>";
			} else {
				$out.= "<li><a  href=\"" . $reload . "&amp;page=" . $i . "\">" . $i . "</a>\n</li>";
			}

		}

		// For next link
		if ($page < $tpages) {
			$out.= "<li><a  href=\"" . $reload . "&amp;page=" . ($page + 1) . "\">" . $nextlabel . "</a>\n</li>";
		}else if ($page == $tpages) {
			$out.= "";
		} else {
			$out.= "<span style='font-size:11px'>" . $nextlabel . "</span>\n";
		}

		//For Last Page Link

		if ($page != $tpages) {
			$out.= "<li><a  href=\"" . $reload . "&amp;page=" . $tpages . "\">" . $lastlabel . "</a>\n</li>";
		}

		$out.= "";
		return $out;
	}
}
?>