﻿<?php

error_reporting(0);
    session_start();
if($_SESSION['validUser']){
    header('location: all-magazine.php');
}


?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="img/favicon.png"/>
    <title>Doha | Login</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen  animated fadeInDown " style="margin-top: -464px !important;">
        <div>
            <p>
                <img src="img/logo.png">
            </p>
            <form class="login-form" method="post">
                <div class="form-group">
                    <input name="name" id="name" class="form-control" placeholder="Username" required="">
                </div>
                <div class="form-group">
                    <input  name="pwd" id="pwd" type="password" class="form-control" placeholder="Password" required="">
                </div>
                <input id= "btnSubmit" type="submit" class="btn btn-primary block full-width m-b" value="Login">
                <!--
                    <a href="#"><small>Forgot password?</small></a>
                -->

                <!--<p class="m-t"> <small>Inspinia we app framework base on Bootstrap 3 &copy; 2014</small> </p>-->
            </form>

        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>


</body>

</html>

<script>

    $(document).ready(function() {
        $(".login-form").on("submit", function(e) {
            e.preventDefault();

            $url = "/ithuse/controller/request.php"
            if($("#name").val()== '' || $("#pwd").val() == ''){
                alert("please select the valid Credential");
                return;
            }

            $.ajax({
                url: "/ithuse/controller/request.php",
                type: "POST",
                data: {
                    "userName": $("#name").val(),
                    "password" : $("#pwd").val(),
                    "requestType" : 'login'
                },
                success: function(data) {
                    if(parseInt(data) == 1){

                        window.location = "all-magazine.php"
                    }else{
                        alert("please select the valid Credential");
                        return;
                    }
                }
            });
        });
    });
</script>