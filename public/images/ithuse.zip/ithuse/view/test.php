<?php
include_once("../model/dbconnect.php");
include_once('../model/paginate.php');
	
	//echo $per_page;
	//$per_page = 3;         // showing number of pages as we wants
	$obj_paginator= new paginator();
	$totl_record= $obj_paginator->getrecord();
	$total_results= $obj_paginator->getrows($totl_record);
	$per_page=$obj_paginator->getrange();
	@$total_pages=$obj_paginator->getpages($total_results, $per_page);
	$arr=$obj_paginator->getfirstlast($total_pages, $per_page);
	$start=$arr[0];
	$end=$arr[1];
	//$end=$obj_paginator->getendpage($total_pages, $per_page);	
	$cls="";

	if (isset($_GET['page'])){
		$show_page = $_GET['page'];    //For finding the status of the current page
	}		
	else{
		$show_page = 1;
	}	
	// display pagination
	@$page = $_GET['page'];
	//echo $page;    For showing the page on which you are.
	$tpages=$total_pages;
	if ($page <= 1)
		$page = 1;
		
?>
<html>
  <head>
	<title>Student Management</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" media="all" href="../css/forms.css">
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="http://jquery.bassistance.de/validate/jquery.validate.js"></script>		
		<script>
			// Jquery validation for Edit form fields 
			$(document).ready(function() {
				
				$(".edit").click(function (){
					$("#"+$(this).data("rowid")).find('input').each(function(){
						//$(this).removeAttr('disabled');
						$(this).show();
					});
					//$("span").hide();
					$("#"+$(this).data("rowid")).find('span').each(function(){
						//$(this).removeAttr('disabled');
						$(this).hide();
					});					
				});	 
			
				$("#btnUpdate").validate({
					rules: {
						country: "required",
						name: {
							required: true,
						},	
						email: {
							required: true,
							email: true
						},
						age: {
							required: true,
							maxlength: 2,
							digits: true
						}
					},
					
					messages: {
						email: {
							email: "Please Enter a valid email id"
						},
						age: {
							maxlength: "Only two Digits are allow"
						}					
					}	
					
				});
			});
		</script>		
  </head>
 <body>
  <div id="container">
	 <form method="get" id="submitForm">
		<fieldset>
			<legend>Student Record</legend>
			<dl>
				<dd>
					<?php
					$reload = $_SERVER['PHP_SELF'] . "?tpages=" . $tpages."&pagination=" . $per_page;
					$paginator = new paginator();
					echo '<div class="pagination"><ul>';
					
					if ($total_pages > 1) {
						echo $paginator->getpaginate($reload, $show_page, $total_pages);
					}
					echo "</ul></div>";
					?>
				</dd>
				<dt>
					<div class="control-group">
						<label class="control-label" for="selectbasic">Select Value</label>
						<div class="controls">
							<select id="pagination" name="pagination" class="input-mini" onChange="this.form.submit()">
							<option value="" style="visibility:hidden"><?php echo((isset($_GET['pagination']))?$_GET['pagination']:"");?></option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
							</select>
						</div>
					</div>			
				</dt>				
			</dl>
			<dl>
				<dd style="width:700px">
					<?php
						echo "<table class='table table-striped'>";
						echo "<thead><tr><th>Student Name</th> <th>Age</th> <th>Email</th> <th>Country</th> <th>Edit</th> <th>Update</th></tr></thead>";
						
						// loop through results of database query, displaying them in the table 
						for ($i = $start; $i < $end; $i++) {
							if ($i == $total_results) {
							break;
							}
						
							// echo out the contents of each row into a table and data with in textbox
							echo "<tr " . $cls . " id='row".$i."'>";
							echo '<td>' .'<input type="text" name="name" value='. @mysql_result($totl_record, $i, "sname").' onClick="#" style="display:none" class="input-small">'. '<span>'. @mysql_result($totl_record, $i, 'sname') .'</span>'.'</td>';
							echo '<td>' .'<input type="text" value='. @mysql_result($totl_record, $i, "age").' onClick="#" style="display:none" class="input-mini">'.'<span>'. @mysql_result($totl_record, $i, 'age') .'</span>'. '</td>';
							echo '<td>' .'<input type="text" value='. @mysql_result($totl_record, $i, "email").' onClick="#" style="display:none" class="input-small">'.'<span>'. @mysql_result($totl_record, $i, 'email') .'</span>'. '</td>';
							echo '<td>' .'<input type="text" value='. @mysql_result($totl_record, $i, "country").' onClick="#" style="display:none" class="input-small">'. '<span>'. @mysql_result($totl_record, $i, 'country') .'</span>'.'</td>';
							echo '<td>'.'<input type="button" data-rowid="row'.$i.'" value="Edit" onClick="#" class="edit">'.'</td>';
							echo '<td>'.'<input type="button" id="btnUpdate" value="Update" onClick="#">'.'</td>';
							echo "</tr>";
						}       
						// close table>
						echo "</table>";
						// pagination
					?>
				</dd>
			</dl>
		</fieldset>
	</form>
  </div>
 </body>
</html>
<input type="text"  