<html>
  <head>
	<title>Student Management</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" media="all" href="../css/forms.css">
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="http://jquery.bassistance.de/validate/jquery.validate.js"></script>		
  </head>
 <body>
  <div id="container">
  	
  </div>
  <script>
  
  		var readFormData = function(){
			return {
				_read  : function(){
					var dataToReturn = {};
					$(document).find('.filter-class').each(function(){
						dataToReturn[$(this).attr('id')] = $(this).val();
					});
					return 	dataToReturn;
				},
				_clear : function(){
					$(document).find('.filter-class').each(function(){
						$(this).attr('value','');
					});
				}
			}
		};
		var formReaderObj = new readFormData();

  		
		function initializeSearchButton(){
			$("#btn_search").on('click' , function(){	
				getPageContent(true);
			});
		}
  
  		function getPageContent($readData){
				var formData = null;
				if($readData)
					formData = formReaderObj._read();
			
				$.ajax({
						url		: "../model/request.php",
						type	: "post",
						data	: {
							"request-type" : "search-result",
							"request-data" : formData
						},
						success	: function(data) {
								$("#container").html(data);
								initializeSearchButton();
						}
				});	
			
		}
		
		function createPagination($pageNumber){
			$("#current_page_number").val($pageNumber);
			getPageContent(true);
		}
		
		
		getPageContent(false);
		
	</script>  
 </body>	
</html>