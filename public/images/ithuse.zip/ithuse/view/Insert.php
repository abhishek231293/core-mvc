<?php include_once("../controller/code.php"); ?>
<?php include_once("../model/dbconnect.php"); ?>
<html>
  <head>
	<title>Student Management</title>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.12.0/jquery.validate.min.js"></script>
	<link rel="stylesheet" type="text/css" media="all" href="../css/forms.css">
	<script>
		// Jquery validation for form fields 
		$(document).ready(function() {
			$("#submitForm").validate({
				rules: {
				    country: "required",
					name: {
						required: true,
					},	
					email: {
						required: true,
						email: true
					},
					age: {
						required: true,
						maxlength: 2,
						digits: true
					}
				},
				
				messages: {
					email: {
						email: "Please Enter a valid email id"
					},
					age: {
						maxlength: "Only two Digits are allow"
					}					
				}	
				
			});
		});
	</script>
  </head>
  <body><div id="container">
	 <form method="post" enctype="multipart/form-data" id="submitForm" action="../controller/code.php">
	 	<fieldset>
			<legend>Student Info</legend>
			<dl>
				<dt><label for="name">Name:</label></dt>
				<dd><input id="name" name="name" type="text" class="input-mini"/></dd>
			</dl>
			<dl>
				<dt><label for="email">Email Address:</label></dt>
				<dd><input type="text" name="email" id="email" size="32" maxlength="128"/></dd>
			</dl>
			<dl>
				<dt><label for="age">Age:</label></dt>
				<dd><input type="text" name="age" id="age" size="32" maxlength="128"/></dd>
			</dl>			
			<dl>
				<dt><label for="country">country:</label></dt>
				<dd>
					<?php
						$obj=new dbconnect();
						$obj->connectdb();
						$sql="SELECT country FROM tbl_country";
						$result=mysql_query($sql);
						$options="";	 			 
						echo '<select name="country" size="1" id="country">';
						echo '<option value="">Select...</option>';
						
						// Fetching country Field from country Table
							while ($row=mysql_fetch_array($result)) {
							$country=$row["country"];
							echo '<option value="'.$country.'">'.$country.'</option>';
							
							}
						echo"</SELECT>";	 
					?>	
				</dd>
			</dl>
			<dl>
				<dt><label for="test"></label></dt>
				<dd><input type="submit" name="submit" value="Submit Record" id="test"></dd>
			</dl>
		</fieldset>
	</form>
</div>
  </body>
</html>
<?php
		if(isset($_REQUEST["q"]))
		echo"<script>alert('Record Inserted Successfully');</script>";
?>	