<?php 
	$requestParam = $viewDataObj->get('requestParam');
?>
	 <form method="get" id="submitForm">
		<fieldset>
			<legend style="width:200px">Student Record</legend>
			<dl>
				<dd>
					<div class="control-group" style="float:left">
						<label for="selectbasic" style="float:left; font-size:15px">Search By</label>
							<select id="searchBy" name="searchBy" class="input-small filter-class"  onChange="" style="float:left; height:25px;margin-left:5px;">
							<option value="">---Select---</option>
							<option value="sname" <?php if(isset($requestParam['searchBy']) && $requestParam['searchBy'] == 'sname'){ echo "selected"; }?>  >Name</option>
							<option value="age"	<?php if(isset($requestParam['searchBy']) && $requestParam['searchBy'] == 'age'){ echo "selected"; }?> 	>Age</option>
							<option value="country"	<?php if(isset($requestParam['searchBy']) && $requestParam['searchBy'] == 'country'){ echo "selected"; }?>  >Country</option>
							</select>
					</div>
					<div style="float:left" class="form-group">
						<input type="text" name="txt_search" id="txt_search" value="<?php if(isset($requestParam['txt_search'])){ echo $requestParam['txt_search'];}?>" class="form-control input-small filter-class" style="margin-left:5px; height:inherit"/>					
					</div>
					<div>
						<input type="button" name="btn_search" id= "btn_search" value="Search" style="margin-left:5px;" class="btn btn-default">			
					</div>	
				</dd>				
			</dl>
			<dl>
				<dd>
					<?php
						echo "<table class='table table-striped'>";
						echo '<thead style="background:hsl(0, 0%, 90%)"><tr><th>Student Name</th> <th>Age</th> <th>Email</th> <th>Country</th></tr></thead>';
							 if( count($viewDataObj->get('resultRowSet') )===0)
							  	echo '<tr><td colspan="4">No Result Found</td></tr>';
						foreach($viewDataObj->get('resultRowSet') as $resultRow){
							echo '<td>' . $resultRow['sname'] . '</td>';
							echo '<td>' . $resultRow['age'] . '</td>';
							echo '<td>' . $resultRow['email'] . '</td>';						
							echo '<td>' . $resultRow['country'] . '</td>';						
							echo "</tr>";
						}       
						// close table>
						echo "</table>";
						// pagination
					?>
				</dd>				
			</dl>
			<dl>
				<dt>
					<div class="control-group" <?php if( count($viewDataObj->get('resultRowSet') )< 3) echo 'style="display:none"'?>>
						<label for="selectbasic" style="font-size:15px">PerPage</label>					
							<select id="pagination" name="pagination" class="input-mini filter-class" onChange="getPageContent(true)" style="height:35px;">
								<?php 
									if($viewDataObj->get('pagination'))
										$val 	= $viewDataObj->get('pagination');
									else
										$val	=0;
								?>
							<option value="3"  <?php if($val=='3') echo "selected";  ?>>3</option>
							<option value="4"  <?php if($val=='4') echo "selected";  ?>>4</option>
							<option value="5"  <?php if($val=='5') echo "selected";  ?>>5</option>
							</select>
					</div>			
				</dt>			
				<dd>
					<div class="pagination" <?php if( count($viewDataObj->get('resultRowSet') )< 3) echo 'style="display:none"'?>>
						<ul>
							<?php echo $viewDataObj->get('paginationContent');?>
						</ul>
						<input type='hidden' class="filter-class" id="current_page_number" name="current_page_number" value="<?php echo $viewDataObj->get('currentPage');?>"/>
					</div>
				</dd>
			</dl>
		</fieldset>
	</form>