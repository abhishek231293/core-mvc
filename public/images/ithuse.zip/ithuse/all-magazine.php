﻿<?php

//print_r($_SESSION);

session_start();
if(!isset($_SESSION['validUser'])){
    header('Location: index.php');
}

?>
<?php
error_reporting(1);
include_once("model/db.php");
include_once("controller/request.php");

include_once('model/paginate.php');

    //echo $per_page;
    //$per_page = 3;         // showing number of pages as we wants
    $obj_paginator= new paginator();
    $totl_record= $obj_paginator->getrecord();
    $total_results= $obj_paginator->getrows($totl_record);

    $per_page=$obj_paginator->getrange();
    @$total_pages=$obj_paginator->getpages($total_results, $per_page);

    $arr=$obj_paginator->getfirstlast($total_pages, $per_page);
    $start=$arr[0];
    $end=$arr[1];
    //$end=$obj_paginator->getendpage($total_pages, $per_page);
    $cls="";

    //echo $totl_record."-------"."$total_results";exit;
    if (isset($_GET['page'])){
        $show_page = $_GET['page'];    //For finding the status of the current page
    }
    else{
        $show_page = 1;
    }
    // display pagination
    @$page = $_GET['page'];
    //echo $page;    For showing the page on which you are.
    $tpages=$total_pages;
    if ($page <= 1)
        $page = 1;

    session_start();
    $_SESSION["totalRecords"] = $total_results

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="img/favicon.png"/>
    <title>Doha | Dashboard</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
                            <span>
                                <img alt="image" class="img-circle" src="img/profile_small.jpg" />
                            </span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear">
                                    <span class="block m-t-xs">
                                        <strong class="font-bold"></strong>
                                    </span> <span class="text-muted text-xs block">Admin <b class="caret"></b></span>
                                </span>
                            </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="changepassword.html">Change Password</a></li>
                                <li class="divider"></li>
                                <li><a href="logout.php">Logout</a></li>
                            </ul>
                        </div>
                        <div class="logo-element">
                            MD
                        </div>
                    </li>
                    <li class="active">
                        <a href="all-magazine.php"><i class="fa fa-book"></i> <span class="nav-label">All Magazine </span>
                            <span class="label label-warning pull-right"><?php echo $_SESSION["totalRecords"]; ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="upload-magazine.php"><i class="fa fa-cloud-upload"></i> <span class="nav-label">Upload Magazine </span></a>
                    </li>
                </ul>
            </div>
        </nav>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                    </div>
                    <ul class="nav navbar-top-links navbar-right">
                        <li>
                            <span class="m-r-sm text-muted welcome-message">Welcome Admin</span>
                        </li>
                        <li>
                            <a href="logout.php">
                                <i class="fa fa-sign-out"></i> Log out
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="wrapper wrapper-content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="ibox float-e-margins">
                                    <div class="ibox-title">
                                        <h5>Magazines</h5>
                                    </div>
                                    <div class="ibox-content">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table table-hover table-striped margin bottom">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 2%" class="text-center">No.</th>
                                                            <th>Name</th>
                                                            <th class="text-right" style="padding-right: 80px;">
                                                                Date Time
                                                            </th>
                                                            <th style="width: 5%"></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php
                                                        if($total_results == 0){ ?>
                                                            <tr>
                                                                <td class="text-center" colspan="4">No Records Found. </td>
                                                            </tr>

                                                        <?php }?>

                                                    <?php for ($i = $start; $i < $end; $i++) {
                                                           if ($i == $total_results) {
                                                                break;
                                                           }
                                                    ?>
                                                        <tr>
                                                            <td class="text-center">
                                                                <?php echo $i+1; ?>
                                                            </td>
                                                            <td><?php echo @mysql_result($totl_record, $i, 'name'); ?></td>
                                                            <td class="text-right">
                                                                <span class="label label-primary">
                                                                    <?php
                                                                        $updateDate =  @mysql_result($totl_record, $i, 'uploaded_at');
                                                                        echo date("d-m-Y", strtotime($updateDate));
                                                                     ?>
                                                                </span>&nbsp;&nbsp;
                                                                <span class="label label-primary">
                                                                    <?php
                                                                        $updateTime =  @mysql_result($totl_record, $i, 'uploaded_at');
                                                                        echo date("h:i A", strtotime($updateDate));
                                                                    ?>

                                                                </span></td>
                                                            <td class="pull-right">
                                                                <?php
                                                                    $resultId =  @mysql_result($totl_record, $i, 'id');
                                                                    $fileName =  @mysql_result($totl_record, $i, 'name');
                                                                    $fileExt  =  @mysql_result($totl_record, $i, 'extension');

                                                                ?>
                                                                <a href="controller/uploads/<?php echo $fileName.'.'.$fileExt; ?>" target="_blank"
                                                                    <i class="fa fa-eye pointer color-green" title="View"></i>&nbsp;&nbsp;
                                                                </a>
                                                                <a onclick="return updateRow('<?php echo $resultId; ?>')">
                                                                    <i class="fa fa-times pointer color-red" title="Delete"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                   <?php } ?>
                                                    </tbody>
                                                </table>
                                                <div class="row">

                                                    <div class="col-sm-6">
                                                        <!--
                                                            <div class="dataTables_info" id="DataTables_Table_0_info" role="status" aria-live="polite">Showing 1 to 6 of 6 entries</div>
                                                        -->
                                                    </div>
                                                    <div class="col-sm-6">

                                                        <?php
                                                        $reload = $_SERVER['PHP_SELF'] . "?tpages=" . $tpages."&pagination=" . $per_page;
                                                        $paginator = new paginator();
                                                        echo '<div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                                                                <ul class="pagination pull-right" style="margin-top: 0; margin-bottom: 0;">';

                                                        if ($total_pages > 1) {
                                                            echo $paginator->getpaginate($reload, $show_page, $total_pages);
                                                        }
                                                        echo "</ul></div>";
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer">
                <div>
                    <strong>Copyright</strong> Example Company &copy; 2014-2015
                </div>
            </div>
        </div>
    </div>
    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <!-- jQuery UI -->
    <script src="js/plugins/jquery-ui/jquery-ui.min.js"></script>

    <!-- Sweet Alert -->
    <script src="js/sweetalert.min.js"></script>
    <link href="css/sweetalert.css" rel="stylesheet">

    <script>
        function updateRow($id){

            var txt;

            //var r = sweetAlert("Are you sure?", "You will not be able to recover this file!", "warning", true, 'btn-danger', 'Yes, delete it!', "No, cancel plx!", false, false);

            var r = sweetAlert({   title: "Are you sure?",
                                    text: "You will not be able to recover this file!",
                                    type: "warning",
                                    showCancelButton: true,
                                    confirmButtonColor: "#DD6B55",
                                    confirmButtonText: "Yes, delete it!",
                                    cancelButtonText: "No, cancel !",
                                    closeOnConfirm: false,
                                    closeOnCancel: false },
                                    function(isConfirm){
                                        if (isConfirm) {
                                            //console.log("here");
                                            $.ajax({
                                                url: "/ithuse/controller/request.php",
                                                type: "POST",
                                                data: {
                                                    "resultId": $id,
                                                    "requestType" : 'update'
                                                },
                                                success: function(data) {

                                                    sweetAlert("Sucess..!", "File deleted SuccessFully !!", "success");
                                                    //window.location = "/ithuse/all-magazine.php"
                                                    location.reload();


                                                }
                                            });

                                        }else{
                                            //window.location = "/ithuse/all-magazine.php"
                                            location.reload();
                                            //console.log("there");
                                        }

                                    });

        }
    </script>
</body>
</html>
