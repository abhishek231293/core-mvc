<?php include_once("../model/db.php"); ?>
<?php

if($_POST['requestType']){
    $request = $_POST['requestType'];
}

switch($request){
    case 'login': $obj=new requestHandler();
                  $obj->login();
    break;
    case 'delete': $obj=new requestHandler();
                  $obj->deleteRecords();
    break;
    case 'update': $obj=new requestHandler();
                  $obj->updateRecords();
    break;
    case 'changePass': $obj=new requestHandler();
                  $obj->updatePass();
    break;
}


class requestHandler{
    function login($request=null){
        $userName = $_POST['userName'];
        $userPassword = $_POST['password'];

        if($request){
            session_start();
            $userName = $_SESSION['validUser'];
            $userPassword = $_POST['oldPassword'];
        }

        $ob = new DbOperation();
        $query = "SELECT * FROM `users` WHERE user_name = '$userName' AND PASSWORD = '$userPassword' ";

        //echo $query;exit;

        $result = 	$ob->selectQuery($query);
        //echo "<pre>";print_r($result);exit;

        if($request){
            return (count($result)) ? '1' : '0';
        }else{
            session_start();
            $_SESSION['validUser'] = $result[0]['user_name'];

            echo (count($result)) ? '1' : '0';
        }

    }

    function getPdfRecords(){

        $ob = new DbOperation();
        $query = "SELECT * FROM `magzine_detail` WHERE is_active = '1'";
        $result = 	$ob->selectQuery($query);
        return $result;
    }

    function deleteRecords(){

        $resultId = $_POST['resultId'];

        $ob = new DbOperation();
        $query = "DELETE  FROM `magzine_detail` WHERE `magzine_detail`.`id` = $resultId ";
        $result = 	$ob->runQuery($query);
        return $result;
    }

    function updateRecords(){

        $resultId = $_POST['resultId'];

        $ob = new DbOperation();
        $query = "UPDATE magzine_detail SET magzine_detail.`is_active` = '0' WHERE `magzine_detail`.`id` = $resultId ";
        $result = 	$ob->runQuery($query);
        return $result;
    }

    function insertRecords($query){

        if($query){
            $ob = new DbOperation();
            $result = 	$ob->runQuery($query);
            return $result;
        }

    }

    function updatePass(){

        $validate = $this->login('chnageRequest');

        //echo $validate;exit;

        if($validate){
            $userName = $_SESSION['validUser'];
            $userPassword = $_POST['oldPassword'];
            $newPassword = $_POST['newPassword'];

            $ob = new DbOperation();
            $query = "UPDATE `users` SET `users`.`password` = '$newPassword'  WHERE `users`.`password`= '$userPassword' AND users.`user_name` = '$userName' ";

            //echo $query;exit;
            $result = 	$ob->runQuery($query);
            echo '1';
        }else{
            echo '0';
        }

    }

    public function getDeviceDetails(){
        $ob = new DbOperation();
        $query = " SELECT * FROM gcm_mapping ";
        $resulRowset = $ob->selectQuery($query);
        return $resulRowset;
    }

    public function sendPushNotification($deviceData){
        //echo "<pre>";print_r($deviceData);
        $registrationIds = array($deviceData['gcm_key']);
        // <a style="background-color: #ed5565;color: #FFFFFF;font-family: Open Sans;font-size: 11px;font-weight: 600; padding-bottom: 4px;padding-left: 6px;padding-right: 6px;text-shadow: none;"> 5 </a>
        $msg = array
        (
            'message' 	=> $deviceData['message'],
            'vibrate'	=> 1,
            'sound'		=> 1,
        );
        $fields = array
        (
            'registration_ids' 	=> $registrationIds,
            'data'			=> $msg
        );


        $headers = array
        (
            'Authorization: key=AIzaSyD3Ysp7ib8OHaXL8Q3v6hLMM1nQe7uIeRU',
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
        curl_setopt( $ch,CURLOPT_POST, true );
        curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
        curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
        $result = curl_exec($ch );
        curl_close( $ch );
        return true; //echo $result;
    }

    public function sendIOSPushNotification($deviceData){
        // Put your device token here (without spaces):
        $deviceToken = $deviceData['gcm_key'];

// Put your private key's passphrase here:
        $passphrase = 'pushHomeAffairs';

// Put your alert message here:
        $message = $deviceData['message'];

////////////////////////////////////////////////////////////////////////////////

        $ctx = stream_context_create();
        stream_context_set_option($ctx, 'ssl', 'local_cert', 'pushDistributionKey.pem');
        stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

// Open a connection to the APNS server
        $fp = stream_socket_client(
            'ssl://gateway.push.apple.com:2195', $err,
            $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

        if (!$fp)
            exit("Failed to connect: $err $errstr" . PHP_EOL);

        echo 'Connected to APNS' . PHP_EOL;

// Create the payload body
        $body['aps'] = array(
            'alert' => $message,
            'sound' => 'default',
            'magazine_id' => $deviceData['magazine_id'],
            'magazine_name' => $deviceData['magazine_name']
        );

// Encode the payload as JSON
        $payload = json_encode($body);

// Build the binary notification
        $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

// Send it to the server
        $result = fwrite($fp, $msg, strlen($msg));

        if (!$result)
            echo 'Message not delivered' . PHP_EOL;
        else
            echo 'Message successfully delivered' . PHP_EOL;

// Close the connection to the server
        fclose($fp);
    }
}

?>