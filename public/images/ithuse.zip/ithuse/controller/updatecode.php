<?php include_once("../model/dbconnect.php"); ?>
<?php include_once("../model/updatedata.php"); 
include_once('../model/paginate.php');?>
<?php
	// Checking form is posted with submission button or not
	$obj_paginator= new paginator();
	$totl_record= $obj_paginator->getrecord();

			/*for($i=0;i<$totl_record;i++){
			
					if($_POST[sname[$i]){
					
						$name=$_POST[sname[$i]];
						$email=$_POST[email[$i]];
						$age=$_POST[age[$i]];
						$country=$_POST[country[$i]];
						$id=$_POST['sid[$i]'];
						break;
					}
			
			
			}*/
			$postData = $_POST;
			$dataToUpdate = array();
			foreach($postData as $index => $value){
				$dataToUpdate[$index] = "";
				foreach( $value as $data){
					$dataToUpdate[$index] = $data;
				}
			}
			
			$checkValid=0;
			// Validation for Email field				
			if (empty($dataToUpdate['email'])){
				echo"Email is required"."<br>";
				$checkValid++;
			}
			else{
				if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$dataToUpdate['email'])){
					echo "Invalid email format"."<br>"; 
					$checkValid++;
				}
			}

			// Validation for Name field				
			if (empty($dataToUpdate['sname'])){
				echo"Name is Required"."<br>";
				$checkValid++;
			}
			
			// Validation for Age field							
			if (empty($dataToUpdate['age'])){
				echo"Name is Required"."<br>";
				$checkValid++;
			}
		
		if($checkValid==0){
		
		$condition = " sid = ".$dataToUpdate['sid'];
		unset($dataToUpdate['sid']);
		// Creating object for Insertion of data
		$ob=new UpdateData();
		$ob->update($dataToUpdate,$condition);
		}
	
?>