<?php include_once("../model/db.php"); ?>

<?php

    $response = array();
    $noError = true;
    if(!isset($_REQUEST['token'])){
        $response['status'] = 'error';
        $response['message'] = "Please provide the authentication key";
        $noError = false;
    }
    if(isset($_REQUEST['token']) && $_REQUEST['token'] != "c2c913091b767bf5afb08a045aa12745"){
        $response['status'] = 'error';
        $response['message'] = "You are not the authentic person to use this";
        $noError = false;
    }
    if(!isset($_REQUEST['request-for'])){
        $response['status'] = 'error';
        $response['message'] = "Request-for parameter is missing";
        $noError = false;
    }
    if(isset($_REQUEST['request-for']) && $_REQUEST['request-for'] == ""){
        $response['status'] = 'error';
        $response['message'] = "Request-for parameter cannot be blank";
        $noError = false;
    }

    if($noError){
        $apiObj = new apiController(new DbOperation());
        switch($_REQUEST['request-for']){
            case 'get-latest-magazine':
                $apiObj->getLatestMagazine();
                break;
            case 'get-all-magazines' :
                $apiObj->getAllMagazineList();
                break;
            case 'update-gcm' :
                $apiObj->updateDeviceGCMKey();
                break;
            case 'default': return 'Invalid call';
                break;

        }
    }
    die(json_encode($response));

    class apiController {
        public $databaseObj;
        public function __construct($databaseObj){
           $this->databaseObj = $databaseObj;
        }

        public function getLatestMagazine(){
            $query = " SELECT *, CONCAT('http://69.60.115.13/ithuse/controller/uploads/', magzine_detail.`name` ,'.', magzine_detail.`extension`)  AS link
                            FROM magzine_detail WHERE is_active = '1' ORDER BY updated_at DESC LIMIT 1";

            $magazineRowset = $this->databaseObj->selectQuery($query);
            $response = array(
                'status' => "ok",
                'data' => $magazineRowset
            );
            die(json_encode($response));
            //echo "<pre>";print_r($magazineRowset);exit;
        }

        public function getAllMagazineList(){
            $condition = "";
            if(isset($_REQUEST['id']) && $_REQUEST['id'] != ""){
                $condition .= " AND id > ".$_REQUEST['id'];
            }
            $query = " SELECT *, CONCAT('/ithuse/controller/uploads/', magzine_detail.`name`, '.', magzine_detail.`extension`)  AS link
                        FROM magzine_detail WHERE is_active = '1' $condition  ORDER BY updated_at DESC";

            $magazineRowset = $this->databaseObj->selectQuery($query);
            $response = array(
                'status' => "ok",
                'data' => $magazineRowset,
                'count' => count($magazineRowset),
                'baseUrl' => $_SERVER['HTTP_HOST']
            );
            die(json_encode($response));
        }

        public function updateDeviceGCMKey(){
            $response = array();
            $noError = true;
            if(!isset($_REQUEST['imei'])){
                $response['status'] = 'error';
                $response['message'] = "Device IMEI parameter is missing";
                $noError = false;
            }
            if($_REQUEST['imei'] == ""){
                $response['status'] = 'error';
                $response['message'] = "Device IMEI parameter cannot be blank";
                $noError = false;
            }
            if(!isset($_REQUEST['gcm_key'])){
                $response['status'] = 'error';
                $response['message'] = "GCM Key parameter is missing";
                $noError = false;
            }
            if($_REQUEST['gcm_key'] == ""){
                $response['status'] = 'error';
                $response['message'] = "GCM Key parameter cannot be blank";
                $noError = false;
            }
            if($noError){
                $deviceImei = $_REQUEST['imei'];
                $gcmKey = $_REQUEST['gcm_key'];
                $deviceType = $_REQUEST['device_type'];

                $query = " SELECT * FROM gcm_mapping WHERE device_imei = '$deviceImei' ";
                $exsitingRow = $this->databaseObj->selectQuery($query);
                if(count($exsitingRow)){
                    $query = " UPDATE magzine_demo_db.gcm_mapping SET gcm_key = '$gcmKey' WHERE device_imei = '$deviceImei' ";
                    $this->databaseObj->runQuery($query);
                }else{
                    $query = " INSERT INTO `magzine_demo_db`.`gcm_mapping` (`device_imei`,`gcm_key`,`created_on`, device_type)
                           VALUES ('$deviceImei','$gcmKey',NOW() , '$deviceType') ";
                    //echo $query;exit;
                    $this->databaseObj->runQuery($query);
                }


                $response['status'] = 'ok';
                $response['message'] = "GCM Key updated successfully";
            }

            die(json_encode($response));

        }
    }

?>