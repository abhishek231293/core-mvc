<?php include_once("../model/db.php");
include_once("request.php");
?>

<?php

$storeFolder = 'uploads';
//phpinfo();
if (!empty($_FILES)) {


	//echo "<pre>";print_r($_FILES);exit;
	//echo "<pre>";print_r($_REQUEST);exit;
/*
	$tempFile = $_FILES['file-0']['tmp_name'];

	echo "<pre>";print_r($tempFile);exit;

	$targetPath = dirname( __FILE__ ) . $ds. $storeFolder . $ds;  //4

	$targetFile =  $targetPath. $_FILES['file-0']['name'];  //5

	move_uploaded_file($tempFile,$targetFile); //6
	echo json_encode(array('success'));
*/

	$info = pathinfo($_FILES['file']['name']);
	$ext = $info['extension']; // get the extension of the file

	if($ext != 'pdf'){
		echo '-1';exit;
	}

	$fileName  = ($_REQUEST['fname']) ? $_REQUEST['fname'] : $info['filename'];
	//$fileName = preg_replace('/\s+/', '_', $fileName);

	//$updatedAt = ($_REQUEST['uplodedDate']) ? date("Y-m-d h:i:s", strtotime($_REQUEST['uplodedDate'])) : date("Y-m-d h:i:s");

	$updatedAt = ($_REQUEST['uplodedDate']) ? date("Y-m-d", strtotime($_REQUEST['uplodedDate'])) : date("Y-m-d");

	$updatedAt = $updatedAt." ".date("H:i:s");

	//echo $updatedAt;exit;

	//echo "<pre>";print_r($info);exit;

	$targetFile = dirname( __FILE__ ) ."/".$storeFolder."/".$fileName.".$ext";

	//echo $targetFile;

	move_uploaded_file( $_FILES['file']['tmp_name'], $targetFile);

	$query = " INSERT INTO `magzine_detail` (NAME,extension, updated_at, uploaded_at) VALUES ('$fileName','$ext', '$updatedAt','$updatedAt')";

	//echo $query;exit;

	$obj=new requestHandler();
	$data = $obj->insertRecords($query);


	/** -- Send Push Notification -- */

	$deviceRowset = $obj->getDeviceDetails();
	if(count($deviceRowset)){
		foreach($deviceRowset as $deviceRow){

			//echo "<pre>";print_r($deviceRow);
			if($deviceRow['device_type'] == "ios"){
				$deviceRow['message'] = "A new magazine for ". date('d-m-Y')." is available";
				$deviceRow['magazine_id'] = $data;
				$deviceRow['magazine_name'] = $fileName;
				$obj->sendIOSPushNotification($deviceRow);
			}else{
				$deviceRow['message'] = "A new magazine for ". date('d-m-Y')." is available #name-".$fileName.",id-".$data;
				$obj->sendPushNotification($deviceRow);
			}
		}
	}
	//echo "<pre>";print_r($dataRowset);exit;

	echo ($data) ? '1' : '0';

}

?>